sap.ui.controller("sap.ca.scfld.md.view.App", {
	onInit : function() {

	},
	
	onExit : function() {

	}
});