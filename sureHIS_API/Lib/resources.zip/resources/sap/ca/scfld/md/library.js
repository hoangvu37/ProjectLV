/*!
 * SAP UI development toolkit for HTML5 (SAPUI5) (c) Copyright
 * 		2009-2012 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.ca.scfld.md.library");jQuery.sap.require("sap.ui.core.Core");jQuery.sap.require("sap.ui.core.library");jQuery.sap.require("sap.viz.library");jQuery.sap.require("sap.m.library");jQuery.sap.require("sap.ca.ui.library");sap.ui.getCore().initLibrary({name:"sap.ca.scfld.md",dependencies:["sap.ui.core","sap.viz","sap.m","sap.ca.ui"],types:[],interfaces:[],controls:[],elements:[],noLibraryCSS:true,version:"1.16.3"});
