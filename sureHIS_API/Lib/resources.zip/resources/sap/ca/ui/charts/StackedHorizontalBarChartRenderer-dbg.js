jQuery.sap.declare("sap.ca.ui.charts.StackedHorizontalBarChartRenderer");
jQuery.sap.require("sap.ca.ui.charts.ChartRenderer");

/**
 * @class StackedHorizontalBarChartRenderer renderer.
 * @static
 */
sap.ca.ui.charts.StackedHorizontalBarChartRenderer = sap.ca.ui.charts.ChartRenderer;