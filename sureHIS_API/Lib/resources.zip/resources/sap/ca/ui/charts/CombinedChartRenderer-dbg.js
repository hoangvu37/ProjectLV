jQuery.sap.declare("sap.ca.ui.charts.CombinedChartRenderer");
jQuery.sap.require("sap.ca.ui.charts.ChartRenderer");

/**
 * @class CombinedChart renderer.
 * @static
 */
sap.ca.ui.charts.CombinedChartRenderer = sap.ca.ui.charts.ChartRenderer;

