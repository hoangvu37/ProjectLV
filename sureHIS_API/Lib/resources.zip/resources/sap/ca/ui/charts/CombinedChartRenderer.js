jQuery.sap.declare("sap.ca.ui.charts.CombinedChartRenderer");jQuery.sap.require("sap.ca.ui.charts.ChartRenderer");sap.ca.ui.charts.CombinedChartRenderer=sap.ca.ui.charts.ChartRenderer;
