jQuery.sap.declare("sap.ca.ui.charts.StackedVerticalColumnChartRenderer");
jQuery.sap.require("sap.ca.ui.charts.ChartRenderer");

/**
 * @class StackedVerticalColumnChartRenderer renderer.
 * @static
 */
sap.ca.ui.charts.StackedVerticalColumnChartRenderer = sap.ca.ui.charts.ChartRenderer;