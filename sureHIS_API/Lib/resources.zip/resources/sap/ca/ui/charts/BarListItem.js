/*!
 * SAP UI development toolkit for HTML5 (SAPUI5) (c) Copyright
 * 		2009-2012 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.ca.ui.charts.BarListItem");jQuery.sap.require("sap.ca.ui.library");jQuery.sap.require("sap.m.ListItemBase");sap.m.ListItemBase.extend("sap.ca.ui.charts.BarListItem",{metadata:{library:"sap.ca.ui",properties:{"axis":{type:"string",group:"Misc",defaultValue:null},"group":{type:"string",group:"Misc",defaultValue:null},"value":{type:"string",group:"Data",defaultValue:null}}}});
