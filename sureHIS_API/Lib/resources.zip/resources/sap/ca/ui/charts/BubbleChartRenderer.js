jQuery.sap.declare("sap.ca.ui.charts.BubbleChartRenderer");jQuery.sap.require("sap.ca.ui.charts.ChartRenderer");sap.ca.ui.charts.BubbleChartRenderer=sap.ca.ui.charts.ChartRenderer;
