jQuery.sap.declare("sap.ca.ui.charts.HorizontalBarChartRenderer");jQuery.sap.require("sap.ca.ui.charts.ChartRenderer");sap.ca.ui.charts.HorizontalBarChartRenderer=sap.ca.ui.charts.ChartRenderer;
