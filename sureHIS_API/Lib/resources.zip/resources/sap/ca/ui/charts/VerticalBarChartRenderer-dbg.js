jQuery.sap.declare("sap.ca.ui.charts.VerticalBarChartRenderer");
jQuery.sap.require("sap.ca.ui.charts.ChartRenderer");

/**
 * @class VerticalBarChart renderer.
 * @static
 */
sap.ca.ui.charts.VerticalBarChartRenderer = sap.ca.ui.charts.ChartRenderer;