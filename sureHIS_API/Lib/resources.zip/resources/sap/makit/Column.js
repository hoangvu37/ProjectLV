/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2013 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.makit.Column");jQuery.sap.require("sap.makit.library");jQuery.sap.require("sap.ui.core.Element");sap.ui.core.Element.extend("sap.makit.Column",{metadata:{library:"sap.makit",properties:{"name":{type:"string",group:"Identification",defaultValue:null},"value":{type:"any",group:"Data",defaultValue:null},"type":{type:"string",group:"Misc",defaultValue:'string'}}}});
/*!
 * @copyright@
 */
