/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2013 SAP AG. All rights reserved
 */

/*
 * Abandoned, empty module (since 1.1.2). Functionality has been integrated into module 'jquery.sap.global'.
 */
jQuery.sap.declare("jquery.sap.logger", false);
