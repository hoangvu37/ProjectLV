﻿using LV.Core.DAL.Base;
using LV.Core.DAL.EntityFramework;
using LV.Poco;
using LV.Common;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Reflection;
using Newtonsoft.Json;

namespace LV.Service.Common
{
    //[AllowAnonymous]
    [RoutePrefix("api/LVCombobox")]
    public class LVComboboxController : LVApiController
    {
        public LVComboboxController()
        {
        }

        #region Services normal combobox

        [Route("LoadDataSource")]
        [HttpGet]
        public IHttpActionResult LoadDataSource(string entityName, int pageNum, int pageSize, string tableFields, string predicate, string valuePredicate, string fieldFilter, string fieldSorting, string sortDirection, bool pageLoading, string fieldCustomPredicate, string valueCustomPredicate, string Assembly = "", string ClassName = "", string Method = "")
        {
            return _LoadDataSource(entityName, pageNum, pageSize, tableFields, predicate, valuePredicate, fieldSorting, sortDirection, pageLoading, Assembly, ClassName, Method);
        }


        private IHttpActionResult _LoadDataSource(string entityName, int pageNum, int pageSize, string tableFields, string predicate, string valuePredicate, string fieldSorting, string sortDirection, bool pageLoading, string Assembly = "", string ClassName = "", string Method = "")
        {
            DataServiceModel dataModel = new DataServiceModel();
            dataModel.TypeName = entityName;
            dataModel.BUID = "";
            dataModel.UserID = "";
            dataModel.PageNum = pageNum;
            dataModel.PageSize = pageSize;
            dataModel.IsViewBUHierarchy = false;
            dataModel.Predicate = CreateLogicPredicate(predicate, dataModel.Predicate);
            dataModel.DataValue = string.IsNullOrEmpty(valuePredicate) ? null : valuePredicate.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
            dataModel.IsPageLoading = pageLoading;
            dataModel.IsSetDataPermission = false;

            if (String.IsNullOrEmpty(fieldSorting) == false)
                dataModel.SortColumns = fieldSorting.Split(';');

            if (String.IsNullOrEmpty(sortDirection) == false)
                dataModel.SortDirections = sortDirection.Split(';');

            if (String.IsNullOrEmpty(tableFields) == false)
            {
                string[] fields = tableFields.Split(';');
                string selector = string.Empty;
                for (int i = 0; i < fields.Length; i++)
                {
                    if (selector == string.Empty)
                        selector = "it." + fields[i] + " as " + fields[i];
                    else
                        selector += "," + "it." + fields[i] + " as " + fields[i];
                }

                dataModel.Selector = String.Format("new({0})", selector);
            }

            Type oType = PocoHelper.GetTypeFromString(dataModel.TypeName);
            if (!string.IsNullOrEmpty(ClassName))
            {
                var mappedPath = System.Web.Hosting.HostingEnvironment.MapPath("~/bin/");
                //nhớ phương thức trả về phải dạng List
                var listData1 = DynamicAssembly.Process(mappedPath, Assembly, ClassName, Method, new object[] { dataModel }, null) as IList;
                return Ok(listData1);
            }
            var listData = DynamicAssembly.InvokeGenericMethod(oType, this, "LoadDataSourceLogic", dataModel, Assembly, ClassName, Method);


            string selectString = "new (";

            var listproperty = tableFields.Split(';');
            foreach (var item in listproperty)
            {
                var it = item.Trim();
                if (selectString != "new (")
                    selectString = selectString + ",";

                selectString = selectString + it + " as " + it;

            }
            selectString = selectString + ")";

            if (listData != null)
                listData = ((IList)listData).AsQueryable().Take(500).Select(selectString, null);

            return Json(listData);
        }

        public IList<TEntity> LoadDataSourceLogic<TEntity>(DataServiceModel oDSM, string Assembly = "", string ClassName = "", string Method = "") where TEntity : class
        {
            IList<TEntity> listData = null;
            if (string.IsNullOrEmpty(ClassName))
            {
                var stop = typeof(TEntity).GetProperty("Stop");
                if (stop != null)
                {
                    if (!string.IsNullOrEmpty(oDSM.Predicate))
                    {
                        oDSM.Predicate = "(" + oDSM.Predicate + ")&&Stop=false";
                    }
                    else
                    {
                        oDSM.Predicate = "Stop=false";
                    }
                }
                DataServices ds = new DataServices();

                listData = ds.GetData(oDSM) as IList<TEntity>;
            }
            return listData;
        }


        [Route("LoadDataSourceAsync")]
        [HttpGet]
        public async Task<object> LoadDataSourceAsync(string entityName,string Stored, int pageNum, int pageSize, string tableFields, string predicate, string valuePredicate, string fieldFilter, string fieldSorting, string sortDirection, bool pageLoading, string fieldCustomPredicate, string valueCustomPredicate, string Assembly = "", string ClassName = "", string Method = "")
        {
            DataServiceModel dataModel = new DataServiceModel();
            dataModel.TypeName = entityName;
            dataModel.BUID = "";
            dataModel.UserID = "";
            dataModel.PageNum = pageNum;
            dataModel.PageSize = pageSize;
            dataModel.IsViewBUHierarchy = false;
            var search = this.Request.GetQueryString("filter.filters[0].value");

            if (entityName.IndexOf("_spCombo") > 0||!string.IsNullOrEmpty(Stored))
            {
                var dataset = this.Repository.ExecuteStoreScalar(entityName, new object[] { search, tableFields.Replace(";", ","), predicate, fieldFilter, fieldSorting, "", "" });
                if (dataset.Tables.Count > 0)
                {

                    return Ok(PocoHelper.GetTableRows(dataset.Tables[0]));
                }
                return Ok();
            }
            Type oType = PocoHelper.GetTypeFromString(dataModel.TypeName);
            if (!string.IsNullOrEmpty(search))
            {
                var exist = false;
                foreach (var item in search)
                {
                    if ("abcdefghijklmnopqrstuvwxyz /-.;:".IndexOf(item.ToString().ToLower()) < 0)
                    {
                        exist = true;
                        break;
                    }

                }

                if (exist == false) search = "nu|" + search + "%";

                var _search = "";
                var p = oType.GetProperties().Where(o => o.PropertyType == typeof(string));
                if (p.Where(o => o.Name == fieldFilter).Any())
                {
                    var item = p.Where(o => o.Name == fieldFilter).FirstOrDefault();
                    if (item.GetCustomAttribute<System.ComponentModel.DataAnnotations.Schema.NotMappedAttribute>() == null)
                    {
                        if (exist == false)
                            _search = _search + item.Name + ".ToLower().Contains(\"" + search.ToLower() + "\")";
                        else
                            _search = _search + item.Name + ".ToLower().IndexOf(\"" + search.ToLower() + "\")==0";
                    }
                }
                else
                {
                    foreach (PropertyInfo item in p)
                    {
                        if (item.GetCustomAttribute<System.ComponentModel.DataAnnotations.Schema.NotMappedAttribute>() == null)
                        {
                            if (_search != "") _search = _search + "||";
                            _search = _search + item.Name + ".ToLower().Contains(\"" + search.ToLower() + "\")";
                        }
                    }
                }

                if (string.IsNullOrEmpty(dataModel.Predicate))
                    dataModel.Predicate = _search;
                else
                {
                    dataModel.Predicate = "(" + dataModel.Predicate + ") && (" + _search + ")";
                }


            }

            dataModel.Predicate = CreateLogicPredicate(predicate, dataModel.Predicate);
            //dataModel.DataValue = string.IsNullOrEmpty(valuePredicate) ? null : valuePredicate.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
            var listTypePre = string.IsNullOrEmpty(valuePredicate) ? null : valuePredicate.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
            var listTtypeObj = listTypePre == null ? null : new List<object>(listTypePre);
            dataModel.DataValue = listTtypeObj == null ? null : ConvertTypeValPredivate(listTtypeObj);
            dataModel.IsPageLoading = pageLoading;
            dataModel.IsSetDataPermission = false;
            if (String.IsNullOrEmpty(fieldSorting) == false)
                dataModel.SortColumns = fieldSorting.Split(';');

            if (String.IsNullOrEmpty(sortDirection) == false)
                dataModel.SortDirections = sortDirection.Split(';');

            if (String.IsNullOrEmpty(tableFields) == false)
            {
                string[] fields = tableFields.Split(';');
                string selector = string.Empty;
                for (int i = 0; i < fields.Length; i++)
                {
                    if (selector == string.Empty)
                        selector = "it." + fields[i] + " as " + fields[i];
                    else
                        selector += "," + "it." + fields[i] + " as " + fields[i];
                }

                dataModel.Selector = String.Format("new({0})", selector);
            }


            if (!string.IsNullOrEmpty(ClassName))
            {
                var mappedPath = System.Web.Hosting.HostingEnvironment.MapPath("~/bin/");
                //nhớ phương thức trả về phải dạng List
                var listData1 = await Task.Factory.StartNew<object>(() =>
                {
                    return DynamicAssembly.Process(mappedPath, Assembly, ClassName, Method, new object[] { dataModel }, null) as IList;
                });
                return Ok(listData1);
            }
            var listData = await DynamicAssembly.InvokeGenericMethodObjAsync(oType, this, "LoadDataSourceLogicAsync", dataModel, Assembly, ClassName, Method);


            string selectString = "new (";

            var listproperty = tableFields.Split(';');
            foreach (var item in listproperty)
            {
                var it = item.Trim();
                if (selectString != "new (")
                    selectString = selectString + ",";

                selectString = selectString + it + " as " + it;

            }
            selectString = selectString + ")";

            var MaxRow = 500;
            if (pageSize != 0) MaxRow = pageSize;
            if (listData != null && ((IList)listData).Count == 0) return Ok();
            if (listData != null)
                listData = ((IList)listData).AsQueryable().Take(MaxRow).Select(selectString, null).Cast<dynamic>().AsEnumerable().ToList();

            return Ok(listData);
        }
        public async Task<object> LoadDataSourceLogicAsync<TEntity>(DataServiceModel oDSM, string Assembly = "", string ClassName = "", string Method = "") where TEntity : class
        {
            // IList<TEntity> listData = null;
            object obj = null;
            if (string.IsNullOrEmpty(ClassName))
            {
                var stop = typeof(TEntity).GetProperty("Stop");
                if (stop != null)
                {
                    if (!string.IsNullOrEmpty(oDSM.Predicate))
                    {
                        oDSM.Predicate = "(" + oDSM.Predicate + ")&&Stop=false";
                    }
                    else
                    {
                        oDSM.Predicate = "Stop=false";
                    }
                }
                DataServices ds = new DataServices();

                obj = await ds.GetDataAsync(oDSM);
            }
            return obj;
        }
        #endregion

        #region Service paging combobox
        /// <summary>
        /// Load dữ liệu phân trang
        /// </summary>
        /// <param name="request">Lệnh request từ datasource. Chỉ chứa 1 phần lệnh request như filter, sort, group,...</param>
        /// <param name="entityName">Tên Entity</param>
        /// <param name="OrderBy">Tên cột sẽ sort</param>
        /// <param name="textfields">Tên column header. Mỗi tên cách nhau bởi dấu ; </param>
        /// <param name="ClassName">Tên class sẽ được gọi (dùng trong trường hợp bạn lấy dữ liệu theo ý bạn từ phương thức của bạn)</param>
        /// <param name="Method">Tên phương thức sẽ được gọi (dùng trong trường hợp bạn lấy dữ liệu theo ý bạn từ phương thức của bạn)</param>
        /// <param name="page">Vị trí trang hiện tại</param>
        /// <param name="pageSize">Số phần tử tối đa trong 1 trang</param>
        /// <param name="predicate">Điều kiện lọc</param>
        /// <param name="valuePredicate">Giá trị lọc (cách nhau bởi dấu |)</param>
        /// <param name="tableInclude">Tên table sẽ được include vào trong câu lệnh LINQ. Mỗi tên table cách nhau bởi dấu ;</param>
        /// <param name="Assembly">Tên Assembly. Thông thường thì tên assembly trùng với tên namespace. Nó là nơi bạn sẽ gọi phương thức của bạn (dùng trong trường hợp bạn lấy dữ liệu theo ý bạn từ phương thức của bạn)</param>
        /// <param name="SortingDirection">Hướng Sort (asc hoặc desc)</param>
        /// <returns></returns>
        [Route("LoadPaging")]
        [HttpGet]
        public IHttpActionResult LoadPaging(string entityName, string OrderBy, string textfields, string ClassName, string Method, int page, int pageSize, string predicate = "", string valuePredicate = "", string tableInclude = "", string Assembly = "", string SortingDirection = "")
        {

            DataServiceModel dataModel = new DataServiceModel();
            dataModel.TypeName = entityName;

            dataModel.SortColumns = string.IsNullOrEmpty(OrderBy) ? new string[] { OrderBy } : OrderBy.Split(';');//new string[] { OrderBy };
            dataModel.SortDirections = string.IsNullOrEmpty(SortingDirection) ? new string[] { "asc" } : SortingDirection.Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
            dataModel.Predicate = CreateLogicPredicate(predicate, dataModel.Predicate);
            dataModel.DataValue = valuePredicate == null ? new string[] { } : valuePredicate.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
            dataModel.PageNum = 1;// (request.Page - 1) * request.PageSize;
            dataModel.PageSize = 3;// request.PageSize;
            dataModel.IsViewBUHierarchy = false;
            dataModel.TableInclue = string.IsNullOrEmpty(tableInclude) ? new string[] { } : tableInclude.Split(new string[] { "; ", ";" }, StringSplitOptions.RemoveEmptyEntries);

            //LVFilterDescriptorCollection lvfdc = new LVFilterDescriptorCollection();

            //var pre = lvfdc.buildPredicate(predicate, valuePredicate);
            //if (pre != null)
            //{
            //    dataModel.Predicate = pre.Keys.ElementAt(0);
            //    dataModel.DataValue = pre[pre.Keys.ElementAt(0)];
            //}

            object[] listData = null;
            if (string.IsNullOrEmpty(Method))
            {
                DataServices ds = new DataServices();
                listData = ds.GetDataPaging(dataModel) as object[];
            }
            else
            {
                var mappedPath = System.Web.Hosting.HostingEnvironment.MapPath("~/bin/");

                //ghi chú: objData phải mang cấu trúc 
                //var objData = new
                //{
                //    Data = (IEnumerable), //dữ liệu trả về kiểu danh sách
                //    Total = (int)//Tổng số trang
                //};
                var objData = DynamicAssembly.Process(mappedPath, Assembly, ClassName, Method, new object[] { dataModel, textfields }, null) as object[];
                IEnumerable list = (IEnumerable)objData[0];
                List<object> displayValues = list.Cast<object>().ToList();
                var re = new
                {
                    Data = (IEnumerable)objData[0],
                    Total = (int)objData[1]
                };
                return Ok(re);
            }

            string selectString = "new (";


            var listproperty = textfields.Split(';');
            foreach (var item in listproperty)
            {
                var it = item.Trim();
                if (selectString != "new (")
                    selectString = selectString + ",";

                selectString = selectString + it + " as " + it;

            }


            selectString = selectString + ")";
            if (listData != null)
                listData[0] = ((IList)listData[0]).AsQueryable().Select(selectString, null);
            var result = new
            {
                Data = (IEnumerable)listData[0],
                Total = (int)listData[1]
            };
            return Json(result);
        }

        [Route("LoadPagingAsync")]
        [HttpGet]
        public async Task<IHttpActionResult> LoadPagingAsync(string entityName, string OrderBy, string textfields, string ClassName, string Method, int page, int pageSize, string predicate = "", string valuePredicate = "", string tableInclude = "", string Assembly = "", string SortingDirection = "")
        {

            DataServiceModel dataModel = new DataServiceModel();
            dataModel.TypeName = entityName;

            dataModel.SortColumns = string.IsNullOrEmpty(OrderBy) ? new string[] { OrderBy } : OrderBy.Split(';');//new string[] { OrderBy };
            dataModel.SortDirections = string.IsNullOrEmpty(SortingDirection) ? new string[] { "asc" } : SortingDirection.Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
            dataModel.Predicate = CreateLogicPredicate(predicate, dataModel.Predicate);
            dataModel.DataValue = valuePredicate == null ? new string[] { } : valuePredicate.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
            dataModel.PageNum = 1;// (request.Page - 1) * request.PageSize;
            dataModel.PageSize = 3;// request.PageSize;
            dataModel.IsViewBUHierarchy = false;
            dataModel.TableInclue = string.IsNullOrEmpty(tableInclude) ? new string[] { } : tableInclude.Split(new string[] { "; ", ";" }, StringSplitOptions.RemoveEmptyEntries);

            //LVFilterDescriptorCollection lvfdc = new LVFilterDescriptorCollection();

            //if (request != null && request.Filters != null)
            //{
            //    foreach (LVFilterDescriptor item in request.Filters)
            //    {
            //        lvfdc.Add(item);
            //    }
            //}
            //var pre = lvfdc.buildPredicate(predicate, valuePredicate);
            //if (pre != null)
            //{
            //    dataModel.Predicate = pre.Keys.ElementAt(0);
            //    dataModel.DataValue = pre[pre.Keys.ElementAt(0)];
            //}

            object[] listData = null;
            if (string.IsNullOrEmpty(Method))
            {
                DataServices ds = new DataServices();
                listData = await ds.GetDataPagingAsync(dataModel) as object[];
            }
            else
            {
                var mappedPath = System.Web.Hosting.HostingEnvironment.MapPath("~/bin/");

                //ghi chú: objData phải mang cấu trúc 
                //var objData = new
                //{
                //    Data = (IEnumerable), //dữ liệu trả về kiểu danh sách
                //    Total = (int)//Tổng số trang
                //};
                var objData = await Task.Factory.StartNew<object[]>(() =>
                {
                    return DynamicAssembly.Process(mappedPath, Assembly, ClassName, Method, new object[] { dataModel, textfields }, null) as object[];
                });

                IEnumerable list = (IEnumerable)objData[0];
                List<object> displayValues = list.Cast<object>().ToList();
                var re = new
                {
                    Data = (IEnumerable)objData[0],
                    Total = (int)objData[1]
                };
                return Ok(re);
            }

            string selectString = "new (";


            var listproperty = textfields.Split(';');
            foreach (var item in listproperty)
            {
                var it = item.Trim();
                if (selectString != "new (")
                    selectString = selectString + ",";

                selectString = selectString + it + " as " + it;

            }


            selectString = selectString + ")";
            if (listData != null)
                listData[0] = ((IList)listData[0]).AsQueryable().Select(selectString, null);
            var result = new
            {
                Data = (IEnumerable)listData[0],
                Total = (int)listData[1]
            };
            return Json(result);
        }

        #endregion

        public class Temp
        {
            public string ObjectID { get; set; }
            public string ObjectName { get; set; }
            public string Phone1 { get; set; }
        }

        [Route("LoadComboboxSapUI")]
        [HttpGet]
        public async Task<IHttpActionResult> LoadComboboxSapUI(string entityName, string selectValue, string selectText, string additionalText, string predicate = "", string valuePredicate = "")
        {
            List<Temp> lTemp = new List<Temp>();
            Temp item = new Temp { ObjectID = "Object 01", ObjectName = "Object Name 01", Phone1 = "0123456789" };
            lTemp.Add(item);

            item = new Temp { ObjectID = "Object 02", ObjectName = "Object Name 02", Phone1 = "012345678910" };
            lTemp.Add(item);
            return Json(lTemp);

        }
        /// <summary>
        /// Biên tập lại câu lệnh predicate gửi từ client. VD như _and_ thành &&
        /// </summary>
        /// <param name="customPredicate">Predicate custom của bạn</param>
        /// <param name="currentPredicate">Predicate hiện tại</param>
        /// <returns></returns>
        private string CreateLogicPredicate(string customPredicate, string currentPredicate)
        {
            if (!string.IsNullOrEmpty(customPredicate))
            {
                customPredicate = customPredicate.Replace('~', '@');//AccountID.IndexOf(~0) -->AccountID.IndexOf(@0)
                customPredicate = customPredicate.Replace("_and_", "&&");//trong url không hiểu giá trị && nên phải ghi là _and_ sau đó mới replace lại. 
                                                                         //VD:SetMultiPredicateComplexForCombo("CashAcctID", "(AccountID.IndexOf(~0)==0_and_AccountID.IndexOf(~1)==0||AccountID.IndexOf(~2)==0)&&!AccountID.Equals(~3)&&Detail.Equals(~4)", "1|4|5|111|true");
                customPredicate = customPredicate.Replace("_equals_", "=");

                if (!string.IsNullOrEmpty(currentPredicate))
                {
                    currentPredicate = "(" + customPredicate + ")&&(" + currentPredicate + ")";
                }
                else
                {
                    currentPredicate = customPredicate;
                }
                if (customPredicate.IndexOf(".") < 0 && customPredicate.IndexOf("=") < 0)//(AccountID", "1") --> (AccountID.Equals(@0)", "1") cho đúng chuẩn
                    currentPredicate = currentPredicate + ".Equals(@0)";
            }
            return currentPredicate;
        }

        #region Convert type value predicate
        /// <summary>
        /// Lấy giá trị của parameter truyền từ url vào
        /// </summary>
        /// <param name="paraName">Tên tham số</param>
        /// <returns></returns>
        internal TypePredicate[] GetOtherValueParam(string paraName)
        {
            var allParams = this.Request.GetQueryStrings();
            string val;
            if (allParams.TryGetValue(paraName, out val))
            {
                TypePredicate[] arrTypePre = JsonConverter.JsonToObject<TypePredicate[]>(val);
                return arrTypePre;
            }
            return new TypePredicate[0];
        }

        /// <summary>
        /// Class xác định các thông tin về type của predicate, cho biết predicate type nào, param ở vị trí thứ mấy sẽ được parse sang type này
        /// </summary>
        internal class TypePredicate
        {
            /// <summary>
            /// Tên predicate
            /// </summary>
            public string name { get; set; }

            /// <summary>
            /// Kiểu dữ liệu của predicate
            /// </summary>
            public string type { get; set; }

            /// <summary>
            /// Vị trí của value predicate. Sẽ parse value predicate ở vị trí này sang kiểu dữ liệu type.
            /// Vd: type là int và index là 0 thì sẽ parse value predicate[0] là int
            /// </summary>
            public int index { get; set; }
        }

        /// <summary>
        /// Chuyển một số item của value predicate sang kiểu dữ liệu phù hợp với type predicate. Vd type predicate là kiều int thì value predicate là kiểu int. Mặc định tất cả value predicate là string
        /// </summary>
        /// <param name="valPre">Mảng value predicate (mảng chứa giá trị lọc)</param>
        /// <returns></returns>
        internal object[] ConvertTypeValPredivate(List<object> valPre)
        {
            if (valPre.Count > 0)
            {
                var arr = GetOtherValueParam("typePredicate");
                for (int i = 0; i < arr.Length; i++)
                {
                    switch (arr[i].type.ToLower())
                    {
                        case "int":
                            valPre[i] = Convert.ChangeType(valPre[i], typeof(int));
                            break;
                        case "bool":
                            valPre[i] = Convert.ChangeType(valPre[i], typeof(bool));
                            break;
                        case "guid":
                            valPre[i] = Convert.ChangeType(valPre[i], typeof(Guid));
                            break;
                    }
                }
            }
            return valPre.ToArray();
        }
        #endregion
    }
}
